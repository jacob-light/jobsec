#' Predicted WARN data
#'
#' Predictions for 2019-20 layoffs by county, output from 
#' warnModeler (using the warnSample data and seed = 25).
#'
#' @name warnPrediction
#' @docType data
#' @keywords data
#'
NULL