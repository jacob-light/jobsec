## ----setup, include=FALSE-----------------------------------------------------
library(magrittr)
knitr::opts_chunk$set(echo = TRUE)

## ----sample_demo, include = FALSE---------------------------------------------
  library(jobsec)
  dim(warnSample)
  head(warnSample)

## ----warn_model, echo = FALSE-------------------------------------------------
  tail(warnPrediction)

## ----warnExtract_example_1----------------------------------------------------
df <- warnExtract(start_date = "2018-01-01", end_date = "2018-08-01", rollup = "year" ,  type_date = "received_date")
head(df)

## ----warnExtract_example_2----------------------------------------------------
df <- warnExtract(warn_data = warnPrediction, start_date = "2018-31-01", end_date = "2019-12-31",counties = c("Alameda County", "Fresno County"))
df

## ----warnBar_example, fig.height = 5, fig.width = 5, fig.align = "center"-----
#Use warnExtract to prep data
df <- warnExtract(start_date = "2015-01-01", end_date = "2018-12-31", rollup = "year",counties = c("Alameda County", "Fresno County"))

#plot by locality
warnBar(df, by = "locality")

## ----warnMap_example, fig.height = 7, fig.width = 7, fig.align = "center"-----
#Use warnExtract to prep data
df <- warnExtract(start_date = "2017-01-01", end_date = "2017-12-31")

#plot
warnMap(df)

