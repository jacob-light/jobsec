# jobsec

Repo for Jesse Rowlands and Jacob Light. Your R package will be `jobsec`.